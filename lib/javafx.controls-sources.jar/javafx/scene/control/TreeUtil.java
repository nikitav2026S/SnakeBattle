/*
 * Copyright (c) 2012, 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package javafx.scene.control;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * A package protected util class used by TreeView and TreeTableView to reduce
 * the level of code duplication.
 */
class TreeUtil {

    static <T> int getExpandedDescendantCount(TreeItem<T> node, boolean treeItemCountDirty) {
        if (node == null) return 0;
        if (node.isLeaf()) return 1;

        return node.getExpandedDescendentCount(treeItemCountDirty);
    }

    static int updateExpandedItemCount(TreeItem treeItem, boolean treeItemCountDirty, boolean isShowRoot) {
        if (treeItem == null) {
            return 0;
        } else if (! treeItem.isExpanded()) {
            return 1;
        } else {
            int count = getExpandedDescendantCount(treeItem, treeItemCountDirty);
            if (! isShowRoot) count--;

            return count;
        }
    }

    static <T> int getRow(TreeItem<T> item, TreeItem<T> root, boolean treeItemCountDirty, boolean isShowRoot) {
        if (item == null) {
            return -1;
        } else if (isShowRoot && item.equals(root)) {
            return 0;
        }

        int row = 0;
        TreeItem<T> i = item;
        TreeItem<T> p = item.getParent();

        TreeItem<T> sibling;
        List<TreeItem<T>> siblings;
        boolean parentIsCollapsed = false;

        while (!i.equals(root) && p != null) {
            if (!p.isExpanded()) {
                parentIsCollapsed = true;
                break;
            }

            siblings = p.children;

            // work up each sibling, from the current item
            int itemIndex = siblings.indexOf(i);
            for (int pos = itemIndex - 1; pos > -1; pos--) {
                sibling = siblings.get(pos);
                if (sibling == null) continue;

                row += getExpandedDescendantCount(sibling, treeItemCountDirty);

                if (sibling.equals(root)) {
                    if (! isShowRoot) {
                        // special case: we've found out that our sibling is
                        // actually the root node AND we aren't showing root nodes.
                        // This means that the item shouldn't actually be shown.
                        return -1;
                    }
                    return row;
                }
            }

            i = p;
            p = p.getParent();

            // we are at the root, does the root match the given root?
            // if not, the item does not exist in the current tree.
            if (p == null && !i.equals(root)) {
                return -1;
            }

            row++;
        }

        return (p == null && row == 0) || parentIsCollapsed ? -1 : isShowRoot ? row : row - 1;
    }

     /**
     * Returns an Iterable that traverses all expanded TreeItems in
     * pre-order depth-first order, starting from root.
     */
    static <T> Iterable<TreeItem<T>> getItems(TreeItem<T> root) {
        return () -> new Iterator<>() {
            private final Deque<TreeItem<T>> stack = new ArrayDeque<>();

            {
                if (root != null) {
                    stack.push(root);
                }
            }

            @Override
            public boolean hasNext() {
                return !stack.isEmpty();
            }

            @Override
            public TreeItem<T> next() {
                if (stack.isEmpty()) {
                    throw new NoSuchElementException();
                }
                TreeItem<T> item = stack.pop();
                if (!item.isLeaf() && item.isExpanded()) {
                    List<TreeItem<T>> children = item.getChildren();
                    for (int i = children.size() - 1; i >= 0; i--) {
                        TreeItem<T> child = children.get(i);
                        if (child != null) {
                            stack.push(child);
                        }
                    }
                }
                return item;
            }
        };
    }
}
