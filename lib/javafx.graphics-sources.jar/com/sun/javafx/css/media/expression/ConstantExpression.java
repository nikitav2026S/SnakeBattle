/*
 * Copyright (c) 2025, 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.javafx.css.media.expression;

import com.sun.javafx.css.media.ContextAwareness;
import com.sun.javafx.css.media.MediaQuery;
import com.sun.javafx.css.media.MediaQueryCache;
import com.sun.javafx.css.media.MediaQueryContext;
import com.sun.javafx.css.media.TriState;
import java.util.Objects;

/**
 * Evaluates to a constant boolean value.
 */
public final class ConstantExpression implements MediaQuery {

    private final boolean value;

    private ConstantExpression(boolean value) {
        this.value = value;
    }

    public static ConstantExpression of(boolean value) {
        return MediaQueryCache.getCachedMediaQuery(new ConstantExpression(value));
    }

    public boolean value() {
        return value;
    }

    @Override
    public int getContextAwareness() {
        return ContextAwareness.NONE.value();
    }

    @Override
    public TriState evaluate() {
        return value ? TriState.TRUE : TriState.FALSE;
    }

    @Override
    public boolean evaluate(MediaQueryContext context) {
        return value;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof ConstantExpression other && value == other.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ConstantExpression.class, value);
    }

    @Override
    public String toString() {
        return "(" + value + ")";
    }
}
