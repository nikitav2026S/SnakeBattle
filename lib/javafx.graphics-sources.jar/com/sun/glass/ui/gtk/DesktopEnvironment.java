/*
 * Copyright (c) 2025, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.glass.ui.gtk;

import java.util.Locale;

/**
 * Linux desktop environments.
 */
enum DesktopEnvironment {
    UNKNOWN,
    GNOME,
    KDE;

    /**
     * Returns the current desktop environment.
     */
    public static DesktopEnvironment current() {
        var result = parse(System.getenv("XDG_CURRENT_DESKTOP"));
        if (result != UNKNOWN) {
            return result;
        }

        result = parse(System.getenv("GDMSESSION"));
        if (result != UNKNOWN) {
            return result;
        }

        if (System.getenv("KDE_FULL_SESSION") != null) {
            return KDE;
        }

        return UNKNOWN;
    }

    private static DesktopEnvironment parse(String value) {
        if (value == null) {
            return UNKNOWN;
        }

        String v = value.toLowerCase(Locale.ROOT);

        if (v.contains("gnome")) {
            return GNOME;
        }

        if (v.contains("kde")) {
            return KDE;
        }

        return UNKNOWN;
    }
}
